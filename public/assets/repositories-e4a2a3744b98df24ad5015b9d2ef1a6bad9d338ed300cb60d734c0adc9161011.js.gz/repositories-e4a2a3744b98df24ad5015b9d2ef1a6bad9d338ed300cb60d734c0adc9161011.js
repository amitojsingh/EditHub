
document.wrtie("new");
